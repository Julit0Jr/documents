package final123project;
import java.util.*;

public class Route {
    public String jeepney;
    public ArrayList<String> route;
    public static Route[] jRoute = new Route[59];
    
    public Route() {
        jeepney = new String();
        route = new ArrayList<>();
    }
}
